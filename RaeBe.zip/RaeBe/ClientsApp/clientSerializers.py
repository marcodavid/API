
from .clientModels import TblClients,TblAddress
from rest_framework import serializers



class ClientsSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = TblClients
        fields = (

            'id_clients',
            'firstname',
            'lastname',
            'email',
            'password',
            'isrenter',
            'age',
            'curp',
            'id_address',
            'imgprofilephoto',
            'fulldata'
        )




class ClientsAuthSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = TblClients
        fields = (


            'email',
            'password'

        )


class AddressSerializer(serializers.HyperlinkedModelSerializer):


    class Meta:
        model = TblAddress
        fields = (

            'id_address',
            'zipcode',
            'country',
            'state',
            'province',
            'numint'
        )
